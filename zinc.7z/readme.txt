=================================================
ZiNc - 3D Arcade Emulator
Release 1.1 - January 25, 2005

Emulator by The_Author and DynaChicken
1.0 series enhancements by R. Belmont and smf

Renderers by Pete Bernert and Lewpy
SPU sound by Pete Bernert
Namco C7x sound simulator by Cap / Team VivaNonno
=================================================

What's this?
------------
ZiNc is an emulator for various arcade games which ran on
modified Sony PlayStation hardware.  It does not emulate 
any other games, including other 3D games.

What's it play?
---------------
To see a complete list of supported games, run ZiNc with the "--list-games" parameter.

ZiNc attempts to provide the fullest possible emulation for each of
these games while also running on relatively low-spec PCs.  However,
we don't guarantee perfect emulation for any of the games.  Sound
and/or music in particular may be incomplete or incorrect for certain
types of games.

ZiNc is not flexible enough to support games with analog controls.  As a
result, some games on supported hardware that you may have seen in
MAME (such as Crypt Killer) are not included.

What's new since ZiNc 1.0.2?
----------------------------
- Correct PSX root counter timing.  This fixes play speed in many System 11 and System 12
  games such as Soul Edge, Tekken 3, Ehrgeiz, and Dancing Eyes (Show Time now works!).
- Replaced unzip engine with a more modern version.  All valid zip files should now 
  work including "zipmax" ones that previous ZiNcs would not recognize.
- Load by CRC32.  Now if ROMs are renamed in MAME ZiNc will still work.
- Fixed improperly defined Soul Edge sets.

What's new since ZiNc 1.0.1?
----------------------------
- Reversed Qsound channels.
- Tekken 3 now runs.  Yes, I know it sounds like hell.  Turn your speakers off.
- sfexp reparented as per MAME 0.88u3, the new US version is the parent.
- Added the release date to the description of all Capcom games so you can tell the
  difference between the 2 US sets of sfexp.
- Fixed misidentified sfex2-series sets.
- Added player 2 controls for Konami GV games.
- Fixed graphical issue in Bloody Roar 2.
- (Linux) libs11player.so now can also be in the LD search path.  This is
  helpful for frontends.

What's new since ZiNc 1.0?
--------------------------
- Disabled Tekken 3 and Super World Stadium '99, both of which were broken.
- Removed --verify switch - it didn't work, and real DATs can be synthesized from 
  the --list-sets output anyway.
- Added Street Fighter EX US version.
- Added -rotate option so vertical monitor games can work on real vertical monitors.
- Synced ROMs with latest MAME.  Again.
- Fixed Susume Taisen Puzzle-Dama on Windows builds - VC++ was miscompiling an inline function.
- Fixed keyboard plugin to support the Konami GV system.

What's new since ZiNc 0.9?
--------------------------
- True ZN decryption instead of ZiNc's old hacks.  Some Capcom games may take 
  a little longer to start up than they did under previous ZiNc versions.  This
  is completely normal
- Story text in Kikaioh / Tech Romancer now works
- Support for Tecmo TPS, Atlus PS, Raizing/Eighting PS Arcade 95, Konami GV,
  and Namco System 12
- Sound simulation for System 11 games, thanks to Team VivaNonno
- Fixed graphics for Tekken and Tekken 2
- MAME-style parent/clone support
- All ROM sets now match MAME 0.87u5 (not a public version)
- CHD support.  These may go either in your ROM folder or in a subdirectory
  of your ROM folder, the same as MAME

What's wrong with it?
---------------------
Sound is not accurate in System 11 games although the simulator does
an excellent job in many cases.

Game speed is wrong in many System 11 games.

Sound is not accurate in System 12 games.

The external sound board is not supported for the Raizing games,
Cool Boarders, or the Taito FX-1b games.


How to use?
-----------
Put roms in the roms/ dir where the emulator is (or the directory
specified by the --roms-directory switch, see below).
Make sure a cfg/ dir exists.

NOTE: for Linux, it's still best to put the 3 plugins somewhere in your
LD path.  E.g. become root, copy them to one of the directories listed
in your /etc/ld.so.conf file (/usr/lib is a reasonable default that
should work on most systems if you can't figure out something better),
run ldconfig, then drop back to being a normal user and run ZiNc.

For the renderer and controller plugins you may use the --renderer=
and --controller= switches as long as you give an absolute path.
Example: ./zinc 12 --controller=./libcontrolznc.so.

type zinc --help to get help
type zinc --list-games to see games
type zinc x - where x is a game nr to start game

type zinc by itself to see all the available options.

Options are:
--help shows help
--list-games lists all games supported
--list-sets  lists the ROM info for all games supported
--version shows the version info
--verify verifies a ROM set
--use-config-file=<value> gets Zinc config info from the filename specified.
--use-renderer-cfg-file=<value> gets renderer config info from the filename 
                                specified.
  A sample renderer config file is provided as "renderer.cfg".
--roms-directory=<value> sets the directory to load ROMs from
--use-sound=<yes|no>            def: yes  turns sound on/off
--renderer=<value>		def: renderer.znc  choose renderer to use
--rotate=<value>                Overrides ZiNc's default screen rotation setting.
                                0 = no rotation, 1 = 90 degrees, 2 = 180 degrees, 3 = 270 degrees.
--controller=<value>		def: controller.znc  choose controller plugin
--use-controller-cfg-file=<value>  def: N/A  gets controller config info from
                                   the specified file.  the default
                                   keyboard plugin ignores this.
--sound-filter-enable=<yes|no>  def: no   turns the sound filter on/off,
                                          provides a quality increase 
                                          with a tiny amount more CPU.
--sound-filter-cutoff=<value>   def: 22050   sets the filter cutoff 
                                             frequency.
--sound-surround-lite-enable=<yes|no> def: no  Enables "Lite-Surround".  Try 
                                               it and listen :)
--sound-surround_lite-multiplier=<value> def:  40  Adjusts how powerful the 
                                                   lite-surround is.
--sound-stereo-exciter=<yes|no> def: no   enables "stereo exciter" which 
                                          widens the stereo image.  Try it 
                                          and listen :)
--use-slow-geometry=<yes|no>    def: no	  uses slower but more accurate 
                                          geometry calculations.  if you see
					  errors, try this as a fix.  
					  Gallop Racer 3 in particular
					  benefits from using the "slow"
					  geometry - the ground breaks up
					  otherwise.


KEYS:

1 - Start player 1
2 - Start player 2
4 - Test switch (enters test mode in most games)
5 - Coin player 1
6 - Coin player 2
7 - Service switch

Cursor Keys - player 1 directions
A,S,D,Z,X,C - player 1 buttons

B, H, N, M - player 2 directions
U,I,O,J,K,L - player 2 buttons

ESC - exits the emulator

F5 - take a snapshot (may depend on the renderer)

The renderers also make use of the insert/home/pageup/delete/end/pagedown
keys for various functions.  These should work approximately the same as
in popular PlayStation emulators.

Troubleshooting
---------------

The first time you run Psychic Force you may go into the test menu.
Select "Factory Defaults" then "Yes" then "Exit".  The screen will say 
"RESET" and just sit there.  Wait a second or two then quit the 
emulator and restart it.  Psychic Force will then play correctly.

Enjoy and have fun!
(c) 1997-2005 The_Author and DynaChicken.  All Rights reserved.
This emulator may be freely distributed as long as the ROM files are not
included and the executable is not modified in any way.  
